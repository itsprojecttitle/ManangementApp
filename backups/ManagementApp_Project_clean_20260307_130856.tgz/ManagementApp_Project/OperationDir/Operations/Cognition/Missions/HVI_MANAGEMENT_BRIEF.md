# Mission Brief: Operation Systems Update - HVI Management

## Purpose:
- To establish `crm/INDEX.md` as the repository for old HVIs requiring reprobing.
- To establish `OperationDir/HVI_INDEX.md` as the primary index for *new* High-Value Individuals (HVI) tracking and management.

## New HVI Data Format (Hubspot CRM style):
- Name
- Age
- Social Media Handles
- Contact Number
- Email Address
- Organization/Affiliation
- Painpoint/Need
- Last Communication Date
- Mission Stage (e.g., #V1, #V2, etc.)

## Reference:
- **Old CRM Index (for Reprobing):** `crm/INDEX.md`
- **New HVI Index:** `OperationDir/HVI_INDEX.md`
- **Initial HVI Criteria:** Refer to `OperationDir/Operations/Artist/Missions/ARTIST_RELEASE_CAMPAIGN_BRIEF.md` for initial HVI criteria definition.