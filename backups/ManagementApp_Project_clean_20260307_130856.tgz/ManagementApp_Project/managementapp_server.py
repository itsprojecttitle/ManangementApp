#!/usr/bin/env python3
import json
import os
import re
import shutil
from datetime import datetime
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

WORKSPACE = Path(__file__).resolve().parent
OPERATIONS_DIR = WORKSPACE / "OperationDir" / "Operations"
BLACKBOOK_FILE = WORKSPACE / "blackbook.crm"
BLACKBOOK_MD_FILE = WORKSPACE / "OperationDir" / "BLACK_BOOK.md"
HVI_INDEX_FILE = WORKSPACE / "OperationDir" / "HVI_INDEX.md"
MISSION_STATUSES = {"PENDING", "IN_PROGRESS", "COMPLETE", "BLOCKED"}


def _safe_name(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_-]+", "_", (name or "").strip()).strip("_") or "Untitled"


def _json_response(handler: SimpleHTTPRequestHandler, payload, status=200):
    body = json.dumps(payload, ensure_ascii=True).encode("utf-8")
    handler.send_response(status)
    handler.send_header("Content-Type", "application/json; charset=utf-8")
    handler.send_header("Cache-Control", "no-store")
    handler.send_header("Content-Length", str(len(body)))
    handler.end_headers()
    handler.wfile.write(body)


def load_operations():
    ops = []
    if OPERATIONS_DIR.exists():
        for p in sorted(OPERATIONS_DIR.iterdir()):
            if p.is_dir() and not p.name.startswith("."):
                ops.append(p.name)
    return ops


def load_missions():
    rows = []
    if not OPERATIONS_DIR.exists():
        return rows
    for op_dir in sorted(OPERATIONS_DIR.iterdir()):
        missions_dir = op_dir / "Missions"
        if not missions_dir.is_dir():
            continue
        for f in sorted(missions_dir.glob("*.md")):
            ts = datetime.fromtimestamp(f.stat().st_mtime).strftime("%Y-%m-%d")
            status = "PENDING"
            content = f.read_text(encoding="utf-8", errors="ignore")
            m = re.search(r"^\s*Status:\s*([A-Z_]+)\s*$", content, re.M)
            if m and m.group(1) in MISSION_STATUSES:
                status = m.group(1)
            rows.append({
                "date": ts,
                "operation": op_dir.name,
                "name": f.stem.replace("_", " "),
                "status": status,
                "path": str(f),
            })
    return rows


def update_mission_status(path: str, status: str) -> bool:
    p = Path(path)
    if status not in MISSION_STATUSES:
        return False
    if not p.exists() or not p.is_file() or not str(p).startswith(str(WORKSPACE)):
        return False

    content = p.read_text(encoding="utf-8", errors="ignore")
    if re.search(r"^\s*Status:\s*[A-Z_]+\s*$", content, re.M):
        content = re.sub(r"^\s*Status:\s*[A-Z_]+\s*$", f"Status: {status}", content, count=1, flags=re.M)
    else:
        content = f"{content.rstrip()}\n\nStatus: {status}\n"
    p.write_text(content, encoding="utf-8")
    return True


def load_blackbook():
    if BLACKBOOK_MD_FILE.exists():
        lines = BLACKBOOK_MD_FILE.read_text(encoding="utf-8", errors="ignore").splitlines()
        header = None
        rows = []
        in_table = False
        for line in lines:
            if line.strip().startswith("|"):
                cells = [c.strip() for c in line.strip().strip("|").split("|")]
                if not in_table:
                    # First table row should be the header row.
                    header = cells
                    in_table = True
                    continue
                # Separator row like | --- | --- |
                if all(set(c) <= {"-", ":"} for c in cells if c):
                    continue
                if header and len(cells) == len(header):
                    row = dict(zip(header, cells))
                    rows.append({
                        "Probe_ID": row.get("Probe_ID", ""),
                        "Hypothesis": row.get("Hypothesis", ""),
                        "Platform": row.get("Platform", ""),
                        "Result_Quantitative": row.get("Result_Quantitative", "PENDING") or "PENDING",
                    })
            elif in_table:
                # End at first non-table line after table starts.
                break
        if rows:
            return rows

    if BLACKBOOK_FILE.exists():
        text = BLACKBOOK_FILE.read_text(encoding="utf-8", errors="ignore")
        status = "PENDING"
        m = re.search(r"\*\*STATUS:\*\*\s*(.+)", text)
        if m:
            status = m.group(1).strip()
        return [{
            "Probe_ID": "T001",
            "Hypothesis": "BLACKBOOK.CRM ENTRY",
            "Platform": "Instagram",
            "Result_Quantitative": status,
        }]
    return []


def delete_blackbook_probe(probe_id: str) -> bool:
    if not probe_id or not BLACKBOOK_MD_FILE.exists():
        return False
    lines = BLACKBOOK_MD_FILE.read_text(encoding="utf-8", errors="ignore").splitlines()
    out = []
    removed = False
    in_table = False
    for line in lines:
        if line.strip().startswith("|"):
            in_table = True
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            # Keep header/separator rows
            if len(cells) > 0 and cells[0] in {"Probe_ID", "--------"}:
                out.append(line)
                continue
            if cells and cells[0] == probe_id:
                removed = True
                continue
            out.append(line)
        else:
            if in_table:
                in_table = False
            out.append(line)
    if removed:
        BLACKBOOK_MD_FILE.write_text("\n".join(out) + "\n", encoding="utf-8")
    return removed


def load_hvi():
    if not HVI_INDEX_FILE.exists():
        return []
    text = HVI_INDEX_FILE.read_text(encoding="utf-8", errors="ignore")
    out = []
    blocks = re.split(r"\n## HVI:\s*", text)
    for b in blocks[1:]:
        lines = b.splitlines()
        if not lines:
            continue
        handle = lines[0].strip()
        stage = "N/A"
        m = re.search(r"\*\s*Mission Stage:\s*(.+)", b)
        if m:
            stage = m.group(1).strip()
        out.append({"handle": handle, "stage": stage})
    return out


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(WORKSPACE), **kwargs)

    def _read_json_body(self):
        length = int(self.headers.get("Content-Length", "0") or 0)
        if length <= 0:
            return {}
        data = self.rfile.read(length)
        try:
            return json.loads(data.decode("utf-8"))
        except Exception:
            return {}

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/operations":
            return _json_response(self, load_operations())
        if path == "/api/missions":
            return _json_response(self, load_missions())
        if path == "/api/blackbook":
            return _json_response(self, load_blackbook())
        if path == "/api/hvi":
            return _json_response(self, load_hvi())
        return super().do_GET()

    def do_POST(self):
        path = urlparse(self.path).path
        body = self._read_json_body()

        if path == "/api/operation":
            op = _safe_name(body.get("name", ""))
            (OPERATIONS_DIR / op / "Missions").mkdir(parents=True, exist_ok=True)
            return _json_response(self, {"ok": True, "operation": op}, 201)

        if path == "/api/mission":
            op = _safe_name(body.get("operation", "ProjectTitle"))
            name = _safe_name(body.get("name", "NEW_MISSION"))
            status = (body.get("status") or "PENDING")
            missions_dir = OPERATIONS_DIR / op / "Missions"
            missions_dir.mkdir(parents=True, exist_ok=True)
            f = missions_dir / f"{name}.md"
            if not f.exists():
                f.write_text(f"# {name}\n\nStatus: {status}\n", encoding="utf-8")
            return _json_response(self, {"ok": True, "path": str(f)}, 201)

        if path == "/api/mission/status":
            mission_path = body.get("path", "")
            status = body.get("status", "")
            if update_mission_status(mission_path, status):
                return _json_response(self, {"ok": True})
            return _json_response(self, {"error": "Invalid mission path or status"}, 400)

        return _json_response(self, {"error": "Not Found"}, 404)

    def do_DELETE(self):
        path = urlparse(self.path).path
        body = self._read_json_body()

        if path == "/api/mission":
            p = Path(body.get("path", ""))
            if p.exists() and str(p).startswith(str(WORKSPACE)) and p.is_file():
                p.unlink()
                return _json_response(self, {"ok": True})
            return _json_response(self, {"error": "Mission file not found"}, 404)

        if path == "/api/operation":
            op = _safe_name(body.get("name", ""))
            p = OPERATIONS_DIR / op
            if p.exists() and p.is_dir():
                shutil.rmtree(p)
                return _json_response(self, {"ok": True})
            return _json_response(self, {"error": "Operation not found"}, 404)

        if path == "/api/blackbook":
            probe_id = body.get("probe_id", "")
            if delete_blackbook_probe(probe_id):
                return _json_response(self, {"ok": True})
            return _json_response(self, {"error": "Probe not found"}, 404)

        return _json_response(self, {"error": "Not Found"}, 404)


if __name__ == "__main__":
    server = ThreadingHTTPServer(("127.0.0.1", 8099), Handler)
    print("ManagementApp server listening on http://127.0.0.1:8099")
    server.serve_forever()
